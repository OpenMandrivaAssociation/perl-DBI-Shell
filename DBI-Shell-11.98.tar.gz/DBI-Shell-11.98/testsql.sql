select * from t
